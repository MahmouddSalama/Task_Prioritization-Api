def main():
    print("Hello from task-prioritization-api!")


if __name__ == "__main__":
    main()
